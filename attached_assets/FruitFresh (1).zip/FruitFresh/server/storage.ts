import {
  users, User, InsertUser,
  categories, Category, InsertCategory,
  products, Product, InsertProduct,
  cartItems, CartItem, InsertCartItem,
  orders, Order, InsertOrder,
  orderItems, OrderItem, InsertOrderItem
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category methods
  getCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  
  // Product methods
  getProducts(filters?: ProductFilters): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  getFeaturedProducts(): Promise<Product[]>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Cart methods
  getCartItems(sessionId: string): Promise<CartItem[]>;
  getCartItemsWithProducts(sessionId: string): Promise<any[]>;
  getCartItemById(id: number): Promise<CartItem | undefined>;
  addToCart(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem | undefined>;
  removeCartItem(id: number): Promise<boolean>;
  clearCart(sessionId: string): Promise<boolean>;
  
  // Order methods
  createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order>;
  getOrderById(id: number): Promise<Order | undefined>;
  getOrderWithItems(id: number): Promise<any>;
  getOrdersBySession(sessionId: string): Promise<Order[]>;
}

export type ProductFilters = {
  categoryId?: number;
  isFeatured?: boolean;
  isOrganic?: boolean;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  isSeasonal?: boolean;
  minPrice?: number;
  maxPrice?: number;
  search?: string;
};

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  
  private currentUserId: number;
  private currentCategoryId: number;
  private currentProductId: number;
  private currentCartItemId: number;
  private currentOrderId: number;
  private currentOrderItemId: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    
    this.currentUserId = 1;
    this.currentCategoryId = 1;
    this.currentProductId = 1;
    this.currentCartItemId = 1;
    this.currentOrderId = 1;
    this.currentOrderItemId = 1;
    
    // Initialize with sample data
    this.initializeData().catch(console.error);
  }

  private async initializeData() {
    // Create default admin user
    const adminUser: InsertUser = {
      username: "admin",
      email: "admin@fruitshop.com",
      password: "admin123"
    };
    const admin = {
      ...adminUser,
      id: this.currentUserId++,
      isAdmin: true
    };
    this.users.set(admin.id, admin);
    
    // Create categories
    const categoriesData: InsertCategory[] = [
      { name: "Seasonal", slug: "seasonal", icon: "apple-fill", color: "#FF6B35" },
      { name: "Citrus", slug: "citrus", icon: "emotion-happy-line", color: "#FF9F1C" },
      { name: "Berries", slug: "berries", icon: "heart-fill", color: "#E63946" },
      { name: "Tropical", slug: "tropical", icon: "sun-fill", color: "#FCBF49" },
      { name: "Organic", slug: "organic", icon: "plant-fill", color: "#4CAF50" },
      { name: "Premium", slug: "premium", icon: "award-fill", color: "#9C27B0" }
    ];
    
    const categories = categoriesData.map(category => {
      const id = this.currentCategoryId++;
      const newCategory: Category = { ...category, id };
      this.categories.set(id, newCategory);
      return newCategory;
    });
    
    // Create products
    const productsData: InsertProduct[] = [
      {
        name: "Fresh Apples",
        slug: "fresh-apples",
        description: "Premium red apples, locally sourced",
        price: 3.99,
        imageUrl: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6",
        unit: "kg",
        stock: 50,
        rating: 4.8,
        isFeatured: true,
        isOrganic: true,
        isBestSeller: false,
        isNewArrival: false,
        isSeasonal: true,
        categoryId: categories[0].id
      },
      {
        name: "Bananas",
        slug: "bananas",
        description: "Cavendish bananas, perfectly ripened",
        price: 2.49,
        imageUrl: "https://images.unsplash.com/photo-1543218024-57a70143c369",
        unit: "kg",
        stock: 75,
        rating: 4.7,
        isFeatured: true,
        isOrganic: false,
        isBestSeller: true,
        isNewArrival: false,
        isSeasonal: false,
        categoryId: categories[3].id
      },
      {
        name: "Strawberries",
        slug: "strawberries",
        description: "Sweet and juicy premium strawberries",
        price: 4.99,
        imageUrl: "https://images.unsplash.com/photo-1588165171080-c89acfa5ee83",
        unit: "box",
        stock: 30,
        rating: 4.9,
        isFeatured: true,
        isOrganic: false,
        isBestSeller: false,
        isNewArrival: false,
        isSeasonal: true,
        categoryId: categories[2].id
      },
      {
        name: "Oranges",
        slug: "oranges",
        description: "Juicy oranges rich in vitamin C",
        price: 3.49,
        imageUrl: "https://images.unsplash.com/photo-1600423115367-87ea7661688f",
        unit: "kg",
        stock: 60,
        rating: 4.6,
        isFeatured: true,
        isOrganic: false,
        isBestSeller: false,
        isNewArrival: false,
        isSeasonal: true,
        categoryId: categories[1].id
      },
      {
        name: "Organic Blueberries",
        slug: "organic-blueberries",
        description: "Fresh organic blueberries packed with antioxidants",
        price: 6.99,
        imageUrl: "https://images.unsplash.com/photo-1498557850523-fd3d118b962e",
        unit: "box",
        stock: 25,
        rating: 4.9,
        isFeatured: false,
        isOrganic: true,
        isBestSeller: true,
        isNewArrival: false,
        isSeasonal: true,
        categoryId: categories[4].id
      },
      {
        name: "Premium Mangoes",
        slug: "premium-mangoes",
        description: "Sweet and fragrant premium imported mangoes",
        price: 7.99,
        imageUrl: "https://images.unsplash.com/photo-1591073113125-e46713c829ed",
        unit: "kg",
        stock: 20,
        rating: 4.8,
        isFeatured: false,
        isOrganic: false,
        isBestSeller: false,
        isNewArrival: true,
        isSeasonal: false,
        categoryId: categories[5].id
      },
      {
        name: "Fresh Avocados",
        slug: "fresh-avocados",
        description: "Creamy, ripe avocados ready to eat",
        price: 5.49,
        imageUrl: "https://images.unsplash.com/photo-1551460188-2f48af84543c",
        unit: "kg",
        stock: 35,
        rating: 4.7,
        isFeatured: false,
        isOrganic: true,
        isBestSeller: true,
        isNewArrival: false,
        isSeasonal: false,
        categoryId: categories[4].id
      },
      {
        name: "Green Grapes",
        slug: "green-grapes",
        description: "Sweet, seedless green grapes",
        price: 4.99,
        imageUrl: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5",
        unit: "kg",
        stock: 40,
        rating: 4.5,
        isFeatured: false,
        isOrganic: false,
        isBestSeller: false,
        isNewArrival: true,
        isSeasonal: true,
        categoryId: categories[0].id
      }
    ];
    
    productsData.forEach(product => {
      const id = this.currentProductId++;
      const newProduct: Product = { ...product, id };
      this.products.set(id, newProduct);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      id, 
      username: insertUser.username,
      email: insertUser.email,
      password: insertUser.password,
      isAdmin: false 
    };
    this.users.set(id, user);
    return user;
  }
  
  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategoryById(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug,
    );
  }
  
  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const newCategory: Category = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }
  
  async updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined> {
    const existingCategory = this.categories.get(id);
    if (!existingCategory) return undefined;
    
    const updatedCategory: Category = { ...existingCategory, ...category };
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }
  
  async deleteCategory(id: number): Promise<boolean> {
    return this.categories.delete(id);
  }
  
  // Product methods
  async getProducts(filters?: ProductFilters): Promise<Product[]> {
    let products = Array.from(this.products.values());
    
    if (filters) {
      if (filters.categoryId !== undefined) {
        products = products.filter(product => product.categoryId === filters.categoryId);
      }
      
      if (filters.isFeatured !== undefined) {
        products = products.filter(product => product.isFeatured === filters.isFeatured);
      }
      
      if (filters.isOrganic !== undefined) {
        products = products.filter(product => product.isOrganic === filters.isOrganic);
      }
      
      if (filters.isBestSeller !== undefined) {
        products = products.filter(product => product.isBestSeller === filters.isBestSeller);
      }
      
      if (filters.isNewArrival !== undefined) {
        products = products.filter(product => product.isNewArrival === filters.isNewArrival);
      }
      
      if (filters.isSeasonal !== undefined) {
        products = products.filter(product => product.isSeasonal === filters.isSeasonal);
      }
      
      if (filters.minPrice !== undefined) {
        products = products.filter(product => product.price >= filters.minPrice!);
      }
      
      if (filters.maxPrice !== undefined) {
        products = products.filter(product => product.price <= filters.maxPrice!);
      }
      
      if (filters.search !== undefined && filters.search !== '') {
        const searchLower = filters.search.toLowerCase();
        products = products.filter(product => 
          product.name.toLowerCase().includes(searchLower) || 
          product.description.toLowerCase().includes(searchLower)
        );
      }
    }
    
    return products;
  }
  
  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }
  
  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.slug === slug,
    );
  }
  
  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.isFeatured,
    );
  }
  
  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.categoryId === categoryId,
    );
  }
  
  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const newProduct: Product = { 
      ...product, 
      id,
      unit: product.unit || "kg",
      stock: product.stock || 0,
      rating: product.rating || 0,
      isFeatured: product.isFeatured || false,
      isOrganic: product.isOrganic || false,
      isBestSeller: product.isBestSeller || false,
      isNewArrival: product.isNewArrival || false,
      isSeasonal: product.isSeasonal || false,
    };
    this.products.set(id, newProduct);
    return newProduct;
  }
  
  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const existingProduct = this.products.get(id);
    if (!existingProduct) return undefined;
    
    const updatedProduct: Product = { ...existingProduct, ...product };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }
  
  // Cart methods
  async getCartItems(sessionId: string): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(
      (item) => item.sessionId === sessionId,
    );
  }
  
  async getCartItemsWithProducts(sessionId: string): Promise<any[]> {
    const cartItems = await this.getCartItems(sessionId);
    
    return Promise.all(cartItems.map(async (item) => {
      const product = await this.getProductById(item.productId);
      return { ...item, product };
    }));
  }
  
  async getCartItemById(id: number): Promise<CartItem | undefined> {
    return this.cartItems.get(id);
  }
  
  async addToCart(cartItem: InsertCartItem): Promise<CartItem> {
    // Check if item already exists in cart
    const existingItem = Array.from(this.cartItems.values()).find(
      (item) => 
        item.sessionId === cartItem.sessionId && 
        item.productId === cartItem.productId
    );
    
    if (existingItem) {
      // Update quantity if item exists
      const updatedItem = { 
        ...existingItem, 
        quantity: existingItem.quantity + (cartItem.quantity || 1)
      };
      this.cartItems.set(existingItem.id, updatedItem);
      return updatedItem;
    }
    
    // Create new cart item if it doesn't exist
    const id = this.currentCartItemId++;
    const createdAt = new Date();
    const newCartItem: CartItem = { 
      id, 
      createdAt,
      productId: cartItem.productId,
      userId: cartItem.userId || null,
      sessionId: cartItem.sessionId || null,
      quantity: cartItem.quantity || 1
    };
    this.cartItems.set(id, newCartItem);
    return newCartItem;
  }
  
  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const cartItem = this.cartItems.get(id);
    if (!cartItem) return undefined;
    
    const updatedCartItem: CartItem = { ...cartItem, quantity };
    this.cartItems.set(id, updatedCartItem);
    return updatedCartItem;
  }
  
  async removeCartItem(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }
  
  async clearCart(sessionId: string): Promise<boolean> {
    const cartItems = await this.getCartItems(sessionId);
    cartItems.forEach(item => this.cartItems.delete(item.id));
    return true;
  }
  
  // Order methods
  async createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    const id = this.currentOrderId++;
    const createdAt = new Date();
    const newOrder: Order = { 
      id, 
      createdAt,
      customerName: order.customerName,
      email: order.email,
      address: order.address,
      city: order.city,
      postalCode: order.postalCode,
      phone: order.phone,
      total: order.total,
      status: order.status || "pending",
      userId: order.userId || null,
      sessionId: order.sessionId || null
    };
    this.orders.set(id, newOrder);
    
    // Create order items
    items.forEach(item => {
      const orderItemId = this.currentOrderItemId++;
      const newOrderItem: OrderItem = { ...item, id: orderItemId, orderId: id };
      this.orderItems.set(orderItemId, newOrderItem);
    });
    
    return newOrder;
  }
  
  async getOrderById(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }
  
  async getOrderWithItems(id: number): Promise<any> {
    const order = await this.getOrderById(id);
    if (!order) return undefined;
    
    const items = Array.from(this.orderItems.values()).filter(
      (item) => item.orderId === id,
    );
    
    return { ...order, items };
  }
  
  async getOrdersBySession(sessionId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.sessionId === sessionId,
    );
  }
}

export const storage = new MemStorage();
