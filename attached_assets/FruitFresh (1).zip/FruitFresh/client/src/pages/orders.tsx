import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Order } from "@shared/schema";
import { Link } from "wouter";
import { Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { formatCurrency } from "@/lib/utils";
import { getStatusColor } from "@/lib/utils";
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardContent 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function OrdersPage() {
  const { user } = useAuth();
  
  const { data: orders, isLoading, error } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
    enabled: !!user
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle>Orders</CardTitle>
            <CardDescription>There was an error loading your orders</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-red-500">Error: {error.message}</p>
            <Link href="/">
              <a className="text-primary hover:underline mt-4 inline-block">Return to home</a>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">My Orders</h1>
        
        {orders && orders.length > 0 ? (
          <div className="space-y-4">
            {orders.map((order) => (
              <Card key={order.id} className="overflow-hidden">
                <div className="flex items-center justify-between bg-gray-50 p-4 border-b">
                  <div>
                    <CardTitle className="text-lg">Order #{order.id}</CardTitle>
                    <CardDescription className="text-sm">
                      {new Date(order.createdAt).toLocaleDateString()} at {new Date(order.createdAt).toLocaleTimeString()}
                    </CardDescription>
                  </div>
                  <Badge className={getStatusColor(order.status)}>
                    {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                  </Badge>
                </div>
                <CardContent className="p-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <h3 className="font-medium text-gray-500">Shipping Address</h3>
                      <p className="mt-1">{order.customerName}</p>
                      <p>{order.address}</p>
                      <p>{order.city}, {order.postalCode}</p>
                      <p>{order.phone}</p>
                    </div>
                    <div className="text-right">
                      <h3 className="font-medium text-gray-500">Order Summary</h3>
                      <p className="mt-1 text-2xl font-bold">{formatCurrency(order.total)}</p>
                      <Link href={`/order/${order.id}`}>
                        <a className="text-primary hover:text-primary-dark hover:underline mt-2 inline-block">
                          View Order Details
                        </a>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <p className="mb-4">You haven't placed any orders yet.</p>
              <Link href="/shop">
                <a className="text-primary hover:text-primary-dark hover:underline">
                  Browse our products
                </a>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}