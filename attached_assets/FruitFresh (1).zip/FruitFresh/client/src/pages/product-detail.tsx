import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useCart } from "@/context/cart-context";
import { formatCurrency } from "@/lib/utils";
import { ProductCard } from "@/components/ui/product-card";
import { Product } from "@shared/schema";

export default function ProductDetail() {
  const { slug } = useParams();
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [isFavorite, setIsFavorite] = useState(false);

  // Fetch product details
  const { data: product, isLoading } = useQuery({
    queryKey: [`/api/products/${slug}`],
  });

  // Fetch related products
  const { data: relatedProducts, isLoading: relatedLoading } = useQuery({
    queryKey: ["/api/products"],
    enabled: !!product,
  });

  const handleDecrease = () => {
    if (quantity > 0.5) {
      setQuantity(quantity - 0.5);
    }
  };

  const handleIncrease = () => {
    setQuantity(quantity + 0.5);
  };

  const handleAddToCart = () => {
    if (!product) return;
    
    addToCart({
      productId: product.id,
      quantity,
    });
    
    toast({
      title: "Added to cart",
      description: `${product.name} (${quantity} ${product.unit}) has been added to your cart.`,
    });
  };

  const handleToggleFavorite = () => {
    setIsFavorite(!isFavorite);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="flex flex-col md:flex-row">
            <Skeleton className="h-[400px] md:w-1/2" />
            <div className="p-6 md:w-1/2">
              <Skeleton className="h-8 w-2/3 mb-4" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-3/4 mb-6" />
              <Skeleton className="h-8 w-1/3 mb-6" />
              <Skeleton className="h-10 w-full mb-4" />
              <Skeleton className="h-10 w-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h2 className="font-poppins font-bold text-2xl text-neutral-dark mb-4">Product not found</h2>
        <p className="text-neutral-dark/70 mb-6">The product you're looking for doesn't exist or has been removed.</p>
        <Link href="/shop">
          <Button className="bg-primary hover:bg-primary/90 text-white">
            Return to Shop
          </Button>
        </Link>
      </div>
    );
  }

  const getBadgeClass = () => {
    if (product.isOrganic) return "bg-secondary text-white";
    if (product.isBestSeller) return "bg-yellow-500 text-white";
    if (product.isNewArrival) return "bg-purple-500 text-white";
    if (product.isSeasonal) return "bg-orange-500 text-white";
    return "bg-primary text-white";
  };

  const getBadgeText = () => {
    if (product.isOrganic) return "Organic";
    if (product.isBestSeller) return "Best Seller";
    if (product.isNewArrival) return "New Arrival";
    if (product.isSeasonal) return "Seasonal";
    return "Featured";
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <div className="text-sm text-neutral-dark/70 mb-4">
        <Link href="/">
          <a className="hover:text-primary">Home</a>
        </Link>
        <span className="mx-2">/</span>
        <Link href="/shop">
          <a className="hover:text-primary">Shop</a>
        </Link>
        <span className="mx-2">/</span>
        <span className="text-neutral-dark">{product.name}</span>
      </div>
      
      {/* Product Details */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-10">
        <div className="flex flex-col md:flex-row">
          {/* Product Image */}
          <div className="md:w-1/2 relative">
            <img 
              src={`${product.imageUrl}?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800`}
              alt={product.name}
              className="w-full h-full object-cover" 
            />
            <div className="absolute top-4 left-4">
              <span className={`text-xs font-bold px-2 py-1 rounded-full ${getBadgeClass()}`}>
                {getBadgeText()}
              </span>
            </div>
          </div>
          
          {/* Product Info */}
          <div className="p-6 md:w-1/2">
            <h1 className="font-poppins font-bold text-3xl text-neutral-dark mb-2">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              <div className="flex items-center text-yellow-400">
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-half-fill"></i>
              </div>
              <span className="text-neutral-dark ml-2">{product.rating} Rating</span>
              <span className="mx-2">•</span>
              <span className="text-green-500">In Stock</span>
            </div>
            
            <p className="text-neutral-dark/70 mb-6 font-opensans">
              {product.description}
            </p>
            
            <div className="mb-6">
              <div className="font-poppins mb-2">
                <span className="font-bold text-3xl text-neutral-dark">{formatCurrency(product.price)}</span>
                <span className="text-sm text-neutral-dark/70">/{product.unit}</span>
              </div>
              {product.isOrganic && (
                <div className="flex items-center text-secondary">
                  <i className="ri-check-line mr-1"></i>
                  <span className="text-sm font-medium">Certified Organic</span>
                </div>
              )}
            </div>
            
            <div className="border-t border-b border-neutral-medium py-4 mb-6">
              <div className="flex justify-between items-center">
                <span className="font-medium text-neutral-dark">Quantity</span>
                <div className="flex items-center space-x-3 bg-neutral-light rounded-lg p-2">
                  <Button 
                    variant="ghost"
                    size="icon"
                    className="w-8 h-8 flex items-center justify-center text-neutral-dark hover:text-primary hover:bg-neutral-medium"
                    onClick={handleDecrease}
                    disabled={quantity <= 0.5}
                    aria-label="Decrease quantity"
                  >
                    <i className="ri-subtract-line"></i>
                  </Button>
                  <span className="font-medium text-neutral-dark w-10 text-center">{quantity}</span>
                  <Button 
                    variant="ghost"
                    size="icon"
                    className="w-8 h-8 flex items-center justify-center text-neutral-dark hover:text-primary hover:bg-neutral-medium"
                    onClick={handleIncrease}
                    aria-label="Increase quantity"
                  >
                    <i className="ri-add-line"></i>
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <Button 
                className="flex-1 bg-primary hover:bg-primary/90 text-white font-medium py-3 rounded-lg flex items-center justify-center gap-2"
                onClick={handleAddToCart}
              >
                <i className="ri-shopping-basket-2-line"></i>
                Add to Basket
              </Button>
              <Button 
                variant="outline"
                className={`flex-1 border border-neutral-medium rounded-lg flex items-center justify-center gap-2 ${isFavorite ? 'text-primary' : 'text-neutral-dark'}`}
                onClick={handleToggleFavorite}
              >
                <i className={isFavorite ? "ri-heart-fill" : "ri-heart-line"}></i>
                Add to Wishlist
              </Button>
            </div>
            
            <div className="space-y-3 text-sm text-neutral-dark/70">
              <div className="flex items-center">
                <i className="ri-truck-line text-primary mr-2"></i>
                <span>Free shipping on orders over $50</span>
              </div>
              <div className="flex items-center">
                <i className="ri-refresh-line text-primary mr-2"></i>
                <span>Easy returns within 14 days</span>
              </div>
              <div className="flex items-center">
                <i className="ri-shield-check-line text-primary mr-2"></i>
                <span>Freshness guaranteed</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Product Details Tabs - simplified for this implementation */}
      <div className="bg-white rounded-xl shadow-sm p-6 mb-10">
        <h2 className="font-poppins font-bold text-2xl text-neutral-dark mb-4">Product Details</h2>
        
        <div className="space-y-4">
          <div>
            <h3 className="font-poppins font-medium text-lg text-neutral-dark mb-2">Description</h3>
            <p className="text-neutral-dark/70 font-opensans">
              {product.description}
              {/* Extended description would go here in a real implementation */}
              {" "}Our fruits are sourced from local farms where they are handpicked at the peak of ripeness to ensure maximum flavor and nutritional value. We pride ourselves on delivering only the freshest produce to your doorstep, often within 24 hours of harvest.
            </p>
          </div>
          
          <div>
            <h3 className="font-poppins font-medium text-lg text-neutral-dark mb-2">Nutritional Information</h3>
            <p className="text-neutral-dark/70 font-opensans">
              Rich in essential vitamins and minerals, our {product.name.toLowerCase()} provide exceptional nutritional benefits. They are an excellent source of dietary fiber and natural sugars, making them a perfect healthy snack option.
            </p>
          </div>
          
          <div>
            <h3 className="font-poppins font-medium text-lg text-neutral-dark mb-2">Storage Tips</h3>
            <p className="text-neutral-dark/70 font-opensans">
              For optimal freshness, store your {product.name.toLowerCase()} in a cool, dry place. Refrigeration is recommended for most fruits to extend their shelf life. Consume within 7 days of delivery for the best taste experience.
            </p>
          </div>
        </div>
      </div>
      
      {/* Related Products */}
      <div className="mb-10">
        <h2 className="font-poppins font-bold text-2xl text-neutral-dark mb-6">You May Also Like</h2>
        
        {relatedLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {Array(4).fill(0).map((_, index) => (
              <Skeleton key={index} className="h-80 rounded-xl" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {relatedProducts
              ?.filter((p: Product) => p.id !== product.id)
              .slice(0, 4)
              .map((relatedProduct: Product) => (
                <ProductCard key={relatedProduct.id} product={relatedProduct} />
              ))}
          </div>
        )}
      </div>
    </div>
  );
}
