import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/utils";

export default function OrderConfirmation() {
  const { id } = useParams();
  const orderId = parseInt(id);

  // Fetch order details
  const { data: order, isLoading, error } = useQuery({
    queryKey: [`/api/orders/${orderId}`],
    enabled: !isNaN(orderId),
  });

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  // Get status badge color
  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return 'bg-green-500 text-white';
      case 'processing':
        return 'bg-blue-500 text-white';
      case 'pending':
        return 'bg-yellow-500 text-white';
      case 'cancelled':
        return 'bg-red-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="max-w-md mx-auto bg-white rounded-xl shadow-sm p-8">
          <i className="ri-error-warning-line text-5xl text-red-500 mb-4"></i>
          <h2 className="font-poppins font-bold text-2xl text-neutral-dark mb-4">Order Not Found</h2>
          <p className="text-neutral-dark/70 mb-6">The order you're looking for doesn't exist or you don't have permission to view it.</p>
          <Link href="/">
            <Button className="bg-primary hover:bg-primary/90 text-white">
              Return to Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center text-primary mx-auto mb-4">
              <i className="ri-check-line text-4xl"></i>
            </div>
            <h1 className="font-poppins font-bold text-3xl text-neutral-dark mb-2">Order Confirmed!</h1>
            <p className="text-neutral-dark/70">
              Thank you for your order. We've received your order and will begin processing it right away.
            </p>
          </div>

          <div className="border border-neutral-medium rounded-lg p-6 mb-8">
            <div className="flex flex-col md:flex-row justify-between mb-4">
              <div>
                <span className="text-sm text-neutral-dark/70">Order Number</span>
                <h3 className="font-poppins font-medium text-lg text-neutral-dark">{`#${order.id}`}</h3>
              </div>
              <div>
                <span className="text-sm text-neutral-dark/70">Date Placed</span>
                <h3 className="font-poppins font-medium text-lg text-neutral-dark">{formatDate(order.createdAt)}</h3>
              </div>
              <div>
                <span className="text-sm text-neutral-dark/70">Status</span>
                <div className="mt-1">
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getStatusBadge(order.status)}`}>
                    {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-poppins font-medium text-neutral-dark mb-2">Shipping Address</h4>
                <div className="text-sm text-neutral-dark/70">
                  <p>{order.customerName}</p>
                  <p>{order.address}</p>
                  <p>{order.city}, {order.postalCode}</p>
                  <p>{order.phone}</p>
                </div>
              </div>
              <div>
                <h4 className="font-poppins font-medium text-neutral-dark mb-2">Payment Method</h4>
                <div className="text-sm text-neutral-dark/70">
                  <p>Cash on Delivery</p>
                </div>
              </div>
            </div>
          </div>

          <h3 className="font-poppins font-medium text-xl text-neutral-dark mb-4">Order Items</h3>
          
          <div className="border border-neutral-medium rounded-lg overflow-hidden mb-6">
            <table className="w-full">
              <thead className="bg-neutral-light">
                <tr>
                  <th className="text-left p-4 font-poppins font-medium text-neutral-dark">Product</th>
                  <th className="text-center p-4 font-poppins font-medium text-neutral-dark">Quantity</th>
                  <th className="text-right p-4 font-poppins font-medium text-neutral-dark">Price</th>
                </tr>
              </thead>
              <tbody>
                {order.items.map((item: any) => (
                  <tr key={item.id} className="border-t border-neutral-medium">
                    <td className="p-4">
                      <div className="font-medium text-neutral-dark">{item.name}</div>
                    </td>
                    <td className="p-4 text-center">
                      <span>{item.quantity} {item.unit}</span>
                    </td>
                    <td className="p-4 text-right">
                      <span>{formatCurrency(item.price * item.quantity)}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex flex-col items-end">
            <div className="w-full md:w-64 space-y-2">
              <div className="flex justify-between">
                <span className="text-neutral-dark/70">Subtotal</span>
                <span className="font-medium text-neutral-dark">{formatCurrency(order.total - 3.99)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-dark/70">Shipping</span>
                <span className="font-medium text-neutral-dark">{formatCurrency(3.99)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-neutral-medium">
                <span className="font-poppins font-medium text-neutral-dark">Total</span>
                <span className="font-poppins font-bold text-lg text-neutral-dark">{formatCurrency(order.total)}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center">
          <p className="text-neutral-dark/70 mb-6">
            An order confirmation has been sent to your email at {order.email}
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/">
              <Button className="bg-primary hover:bg-primary/90 text-white">
                Back to Home
              </Button>
            </Link>
            <Link href="/shop">
              <Button variant="outline">
                Continue Shopping
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
