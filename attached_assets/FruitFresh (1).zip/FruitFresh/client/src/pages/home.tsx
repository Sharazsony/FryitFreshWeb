import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/ui/product-card";
import { Category, Product } from "@shared/schema";
import { getCategoryColorClass } from "@/lib/utils";

export default function Home() {
  const [email, setEmail] = useState("");
  
  const { data: categories, isLoading: categoriesLoading } = useQuery({
    queryKey: ["/api/categories"],
  });
  
  const { data: featuredProducts, isLoading: productsLoading } = useQuery({
    queryKey: ["/api/products", { featured: true }],
  });
  
  const handleEmailSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    alert(`Discount code sent to ${email}`);
    setEmail("");
  };
  
  return (
    <div>
      {/* Hero Banner */}
      <section className="relative bg-gradient-primary text-white overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <i className="ri-apple-fill text-8xl absolute top-10 left-[10%]"></i>
          <i className="ri-android-fill text-8xl absolute bottom-10 right-[5%]"></i>
          <i className="ri-football-fill text-8xl absolute top-[60%] left-[30%]"></i>
        </div>
        
        <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
          <div className="md:w-1/2">
            <h1 className="font-poppins font-bold text-4xl md:text-5xl leading-tight mb-4">
              Fresh Fruits Delivered To Your Doorstep
            </h1>
            <p className="font-opensans text-lg mb-8 text-white/90">
              Handpicked seasonal fruits, sourced from local farms and delivered fresh daily.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/shop">
                <Button className="inline-block bg-white text-primary font-poppins font-medium px-8 py-3 rounded-full shadow-lg hover:shadow-xl transition-shadow text-center">
                  Shop Now
                </Button>
              </Link>
              <Link href="/shop?category=seasonal">
                <Button variant="outline" className="inline-block bg-transparent border-2 border-white text-white font-poppins font-medium px-8 py-3 rounded-full hover:bg-white/10 transition-colors text-center">
                  Browse Categories
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Categories Section */}
      <section id="categories" className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-3xl text-neutral-dark text-center mb-2">Browse by Category</h2>
          <p className="text-center text-neutral-dark/70 mb-10 font-opensans">Discover our wide range of fresh fruits</p>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {categoriesLoading ? (
              Array(6).fill(0).map((_, index) => (
                <div key={index} className="animate-pulse">
                  <div className="bg-neutral-light rounded-xl p-6 flex flex-col items-center text-center">
                    <div className="w-16 h-16 bg-gray-300 rounded-full mb-4"></div>
                    <div className="h-5 bg-gray-300 rounded w-20"></div>
                  </div>
                </div>
              ))
            ) : (
              categories?.map((category: Category) => (
                <Link key={category.id} href={`/shop?category=${category.slug}`}>
                  <a className="group">
                    <div className="bg-neutral-light rounded-xl p-6 flex flex-col items-center text-center transition-all group-hover:shadow-md group-hover:scale-105">
                      <div className={`w-16 h-16 flex items-center justify-center ${getCategoryColorClass(category.color).replace('text-white', 'text-white/90').replace('bg-', 'bg-opacity-10 bg-')} rounded-full mb-4`}>
                        <i className={`ri-${category.icon} text-2xl`}></i>
                      </div>
                      <h3 className="font-poppins font-medium text-neutral-dark group-hover:text-primary transition-colors">
                        {category.name}
                      </h3>
                    </div>
                  </a>
                </Link>
              ))
            )}
          </div>
        </div>
      </section>
      
      {/* Featured Products */}
      <section id="shop" className="py-12 bg-neutral-light">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-10">
            <div>
              <h2 className="font-poppins font-bold text-3xl text-neutral-dark mb-2">Featured Fruits</h2>
              <p className="text-neutral-dark/70 font-opensans">Our best selling seasonal selections</p>
            </div>
            
            <div className="mt-4 md:mt-0 flex items-center space-x-2 overflow-x-auto md:overflow-visible py-2 md:py-0">
              <Button variant="outline" className="px-4 py-2 bg-white border border-neutral-medium rounded-full text-sm font-medium text-neutral-dark hover:bg-neutral-medium transition-colors">
                All
              </Button>
              <Link href="/shop?seasonal=true">
                <Button variant="outline" className="px-4 py-2 bg-white border border-neutral-medium rounded-full text-sm font-medium text-neutral-dark hover:bg-neutral-medium transition-colors">
                  Seasonal
                </Button>
              </Link>
              <Link href="/shop?bestseller=true">
                <Button variant="outline" className="px-4 py-2 bg-white border border-neutral-medium rounded-full text-sm font-medium text-neutral-dark hover:bg-neutral-medium transition-colors">
                  Bestsellers
                </Button>
              </Link>
              <Link href="/shop?newarrival=true">
                <Button variant="outline" className="px-4 py-2 bg-white border border-neutral-medium rounded-full text-sm font-medium text-neutral-dark hover:bg-neutral-medium transition-colors">
                  New Arrivals
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {productsLoading ? (
              Array(4).fill(0).map((_, index) => (
                <div key={index} className="animate-pulse bg-white rounded-xl overflow-hidden shadow-sm">
                  <div className="h-48 bg-gray-300"></div>
                  <div className="p-4">
                    <div className="h-6 bg-gray-300 rounded mb-2"></div>
                    <div className="h-4 bg-gray-300 rounded mb-3 w-3/4"></div>
                    <div className="h-6 bg-gray-300 rounded mb-4"></div>
                    <div className="h-10 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))
            ) : (
              featuredProducts?.slice(0, 4).map((product: Product) => (
                <ProductCard key={product.id} product={product} />
              ))
            )}
          </div>
          
          <div className="mt-10 text-center">
            <Link href="/shop">
              <Button className="inline-block text-primary border border-primary font-poppins font-medium px-8 py-3 rounded-full hover:bg-primary hover:text-white transition-colors">
                View All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Promotion Banner */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="bg-gradient-primary rounded-2xl overflow-hidden shadow-lg">
            <div className="flex flex-col md:flex-row items-center">
              <div className="p-8 md:p-12 md:w-1/2 text-white">
                <span className="inline-block bg-white text-primary px-4 py-1 rounded-full text-sm font-medium mb-4">Limited Time Offer</span>
                <h2 className="font-poppins font-bold text-3xl md:text-4xl mb-4">Get 20% Off On Your First Order</h2>
                <p className="text-white/90 mb-6 font-opensans">
                  Sign up today and receive a special discount on your first purchase. Fresh fruits delivered straight to your door.
                </p>
                <form className="flex flex-col sm:flex-row gap-2 max-w-md" onSubmit={handleEmailSubmit}>
                  <input 
                    type="email" 
                    placeholder="Enter your email" 
                    className="px-4 py-3 rounded-lg flex-grow text-neutral-dark focus:outline-none focus:ring-2 focus:ring-yellow-400" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                  <Button type="submit" className="bg-accent hover:bg-accent/90 text-white px-6 py-3 rounded-lg font-medium transition-colors">
                    Get Discount
                  </Button>
                </form>
              </div>
              
              <div className="md:w-1/2 p-8 hidden md:block">
                <img 
                  src="https://images.unsplash.com/photo-1519996529931-28324d5a630e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                  alt="Collection of fresh fruits" 
                  className="w-full h-auto rounded-lg shadow-lg" 
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Testimonials */}
      <section className="py-12 bg-neutral-light">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-3xl text-neutral-dark text-center mb-2">What Our Customers Say</h2>
          <p className="text-center text-neutral-dark/70 mb-10 font-opensans">Hear from our satisfied customers</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-4 bg-neutral-medium">
                    <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100" alt="Sarah Johnson" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h4 className="font-poppins font-medium text-neutral-dark">Sarah Johnson</h4>
                    <p className="text-sm text-neutral-dark/70">Loyal Customer</p>
                  </div>
                </div>
                <div className="text-yellow-400">
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                </div>
              </div>
              <p className="text-neutral-dark font-opensans">
                "The quality of fruits from FruitMarket is exceptional! Always fresh and tasty. Their delivery is prompt and the packaging is eco-friendly. Highly recommend!"
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-4 bg-neutral-medium">
                    <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100" alt="Michael Chen" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h4 className="font-poppins font-medium text-neutral-dark">Michael Chen</h4>
                    <p className="text-sm text-neutral-dark/70">New Customer</p>
                  </div>
                </div>
                <div className="text-yellow-400">
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-half-fill"></i>
                </div>
              </div>
              <p className="text-neutral-dark font-opensans">
                "I've been ordering my weekly fruit supply from FruitMarket for a month now, and I'm impressed by the consistency in quality. Their seasonal selections are always a delight!"
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-4 bg-neutral-medium">
                    <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100" alt="Emily Rodriguez" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h4 className="font-poppins font-medium text-neutral-dark">Emily Rodriguez</h4>
                    <p className="text-sm text-neutral-dark/70">Regular Customer</p>
                  </div>
                </div>
                <div className="text-yellow-400">
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                </div>
              </div>
              <p className="text-neutral-dark font-opensans">
                "The premium fruit box subscription is amazing! My family loves the variety and freshness. Customer service is also excellent - they quickly resolved an issue with my order."
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* How It Works */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-3xl text-neutral-dark text-center mb-2">How It Works</h2>
          <p className="text-center text-neutral-dark/70 mb-10 font-opensans">Simple steps to get fresh fruits delivered</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center text-primary mb-4">
                <i className="ri-shopping-basket-2-line text-3xl"></i>
              </div>
              <h3 className="font-poppins font-medium text-xl text-neutral-dark mb-2">1. Choose Your Fruits</h3>
              <p className="text-neutral-dark/70 font-opensans">Browse our wide selection of fresh fruits and add your favorites to your basket.</p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-secondary/10 rounded-full flex items-center justify-center text-secondary mb-4">
                <i className="ri-wallet-3-line text-3xl"></i>
              </div>
              <h3 className="font-poppins font-medium text-xl text-neutral-dark mb-2">2. Place Your Order</h3>
              <p className="text-neutral-dark/70 font-opensans">Complete your order by providing delivery details and making payment securely.</p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-accent/10 rounded-full flex items-center justify-center text-accent mb-4">
                <i className="ri-truck-line text-3xl"></i>
              </div>
              <h3 className="font-poppins font-medium text-xl text-neutral-dark mb-2">3. Get Fresh Delivery</h3>
              <p className="text-neutral-dark/70 font-opensans">Sit back and relax as we deliver fresh fruits directly to your doorstep.</p>
            </div>
          </div>
          
          <div className="mt-10 text-center">
            <Link href="/shop">
              <Button className="inline-block bg-primary text-white font-poppins font-medium px-8 py-3 rounded-full shadow-md hover:shadow-lg hover:bg-primary/90 transition">
                Start Shopping Now
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
