import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { checkoutSchema, CartItemWithProduct } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useCart } from "@/context/cart-context";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { CartItem } from "@/components/ui/cart-item";
import { formatCurrency } from "@/lib/utils";
import { Link } from "wouter";

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { cartItems, isLoading: cartLoading, clearCart } = useCart();
  const { toast } = useToast();
  
  // Extended checkout schema
  const form = useForm({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      customerName: "",
      email: "",
      address: "",
      city: "",
      postalCode: "",
      phone: "",
    },
  });
  
  // Calculate cart totals
  const subtotal = cartItems.reduce((total, item) => {
    return total + (item.product.price * item.quantity);
  }, 0);
  
  const shipping = subtotal > 0 ? 3.99 : 0;
  const total = subtotal + shipping;
  
  // Create order mutation
  const createOrderMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/orders", data);
    },
    onSuccess: (data) => {
      clearCart();
      setLocation(`/order/${data.id}`);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to place order: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (data: any) => {
    if (cartItems.length === 0) {
      toast({
        title: "Empty Cart",
        description: "Your cart is empty. Add some items before checking out.",
        variant: "destructive",
      });
      return;
    }
    
    createOrderMutation.mutateAsync(data);
  };
  
  if (cartLoading) {
    return (
      <div className="container mx-auto px-4 py-8 flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="max-w-md mx-auto bg-white rounded-xl shadow-sm p-8">
          <i className="ri-shopping-basket-2-line text-5xl text-primary mb-4"></i>
          <h2 className="font-poppins font-bold text-2xl text-neutral-dark mb-4">Your Cart is Empty</h2>
          <p className="text-neutral-dark/70 mb-6">Add some fresh fruits to your basket before proceeding to checkout.</p>
          <Link href="/shop">
            <Button className="bg-primary hover:bg-primary/90 text-white">
              Browse Products
            </Button>
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="font-poppins font-bold text-3xl text-neutral-dark mb-6">Checkout</h1>
      
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Customer Information Form */}
        <div className="lg:w-2/3">
          <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
            <h2 className="font-poppins font-medium text-xl text-neutral-dark mb-4">
              Shipping Information
            </h2>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="customerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input placeholder="john.doe@example.com" type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <Input placeholder="123 Fruit Street" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input placeholder="Fruitville" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="postalCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Postal Code</FormLabel>
                        <FormControl>
                          <Input placeholder="12345" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="(555) 123-4567" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div>
                  <h3 className="font-poppins font-medium text-lg text-neutral-dark mb-2 mt-6">
                    Payment Method
                  </h3>
                  <div className="bg-neutral-light p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <input
                        type="radio"
                        id="cash-on-delivery"
                        name="payment-method"
                        className="mr-2"
                        checked
                        readOnly
                      />
                      <label htmlFor="cash-on-delivery" className="font-medium">
                        Cash on Delivery
                      </label>
                    </div>
                    <p className="text-sm text-neutral-dark/70">
                      Pay in cash when your order is delivered.
                    </p>
                  </div>
                </div>
                
                <div className="border-t border-neutral-medium pt-6 mt-6 flex justify-end">
                  <Link href="/shop">
                    <Button type="button" variant="outline" className="mr-4">
                      Continue Shopping
                    </Button>
                  </Link>
                  <Button 
                    type="submit" 
                    className="bg-primary hover:bg-primary/90 text-white"
                    disabled={createOrderMutation.isPending}
                  >
                    {createOrderMutation.isPending ? (
                      <>
                        <span className="animate-spin mr-2">
                          <i className="ri-loader-4-line"></i>
                        </span>
                        Processing...
                      </>
                    ) : "Place Order"}
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        </div>
        
        {/* Order Summary */}
        <div className="lg:w-1/3">
          <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
            <h2 className="font-poppins font-medium text-xl text-neutral-dark mb-4">
              Order Summary
            </h2>
            
            <div className="max-h-[400px] overflow-y-auto mb-4 pr-2">
              {cartItems.map((item: CartItemWithProduct) => (
                <CartItem key={item.id} item={item} compact />
              ))}
            </div>
            
            <div className="border-t border-neutral-medium pt-4 space-y-2">
              <div className="flex justify-between text-neutral-dark">
                <span>Subtotal</span>
                <span className="font-medium">{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between text-neutral-dark">
                <span>Shipping</span>
                <span className="font-medium">{formatCurrency(shipping)}</span>
              </div>
              <div className="flex justify-between font-poppins font-bold text-lg text-neutral-dark pt-2 border-t border-neutral-medium">
                <span>Total</span>
                <span>{formatCurrency(total)}</span>
              </div>
            </div>
            
            <div className="mt-6 bg-neutral-light p-4 rounded-lg">
              <div className="flex items-center text-green-600 mb-2">
                <i className="ri-shield-check-line mr-2"></i>
                <span className="font-medium">Secure Checkout</span>
              </div>
              <p className="text-sm text-neutral-dark/70">
                Your personal data will be used to process your order, support your experience, and for other purposes described in our privacy policy.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
