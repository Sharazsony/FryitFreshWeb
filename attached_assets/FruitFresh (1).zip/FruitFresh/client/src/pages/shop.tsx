import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/ui/product-card";
import { Product, Category } from "@shared/schema";
import { getCategoryColorClass } from "@/lib/utils";

export default function Shop() {
  const [, params] = useLocation();
  const searchParams = new URLSearchParams(params);
  
  // Filters
  const [selectedCategory, setSelectedCategory] = useState<string | null>(
    searchParams.get("category") || null
  );
  const [priceRange, setPriceRange] = useState<number[]>([0, 10]);
  const [isFeatured, setIsFeatured] = useState<boolean>(
    searchParams.get("featured") === "true"
  );
  const [isOrganic, setIsOrganic] = useState<boolean>(
    searchParams.get("organic") === "true"
  );
  const [isBestSeller, setIsBestSeller] = useState<boolean>(
    searchParams.get("bestseller") === "true"
  );
  const [isNewArrival, setIsNewArrival] = useState<boolean>(
    searchParams.get("newarrival") === "true"
  );
  const [isSeasonal, setIsSeasonal] = useState<boolean>(
    searchParams.get("seasonal") === "true"
  );
  const [searchQuery, setSearchQuery] = useState<string>(
    searchParams.get("search") || ""
  );
  
  // Get categories
  const { data: categories, isLoading: categoriesLoading } = useQuery({
    queryKey: ["/api/categories"],
  });
  
  // Build filter params
  const buildQueryParams = () => {
    const params: any = {};
    
    if (selectedCategory) {
      const category = categories?.find((c: Category) => c.slug === selectedCategory);
      if (category) {
        params.categoryId = category.id;
      }
    }
    
    if (isFeatured) params.featured = true;
    if (isOrganic) params.organic = true;
    if (isBestSeller) params.bestseller = true;
    if (isNewArrival) params.newarrival = true;
    if (isSeasonal) params.seasonal = true;
    if (priceRange[0] > 0) params.minPrice = priceRange[0];
    if (priceRange[1] < 10) params.maxPrice = priceRange[1];
    if (searchQuery) params.search = searchQuery;
    
    return params;
  };
  
  // Get products with filters
  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ["/api/products", buildQueryParams()],
  });
  
  // Handle filter changes
  const handleCategoryChange = (slug: string) => {
    setSelectedCategory(selectedCategory === slug ? null : slug);
  };
  
  const handleSearchSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    setSearchQuery(formData.get("search") as string);
  };
  
  const clearFilters = () => {
    setSelectedCategory(null);
    setPriceRange([0, 10]);
    setIsFeatured(false);
    setIsOrganic(false);
    setIsBestSeller(false);
    setIsNewArrival(false);
    setIsSeasonal(false);
    setSearchQuery("");
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar - Filters */}
        <div className="md:w-1/4">
          <div className="bg-white p-6 rounded-xl shadow-sm mb-6">
            <h3 className="font-poppins font-medium text-xl text-neutral-dark mb-4">Search</h3>
            <form onSubmit={handleSearchSubmit}>
              <div className="flex items-center">
                <Input 
                  type="text" 
                  name="search"
                  placeholder="Search fruits..." 
                  className="w-full rounded-lg" 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Button type="submit" className="ml-2 bg-primary hover:bg-primary/90">
                  <i className="ri-search-line"></i>
                </Button>
              </div>
            </form>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-poppins font-medium text-xl text-neutral-dark">Filters</h3>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={clearFilters}
                className="text-primary hover:text-primary/80 p-0 h-auto font-medium"
              >
                Clear All
              </Button>
            </div>
            
            <div className="space-y-6">
              <div>
                <h4 className="font-poppins font-medium text-neutral-dark mb-3">Categories</h4>
                {categoriesLoading ? (
                  <div className="animate-pulse space-y-2">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="h-6 bg-gray-200 rounded"></div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {categories?.map((category: Category) => (
                      <div key={category.id} className="flex items-center">
                        <Checkbox 
                          id={`category-${category.id}`}
                          checked={selectedCategory === category.slug}
                          onCheckedChange={() => handleCategoryChange(category.slug)}
                        />
                        <label 
                          htmlFor={`category-${category.id}`}
                          className="ml-2 text-sm font-medium cursor-pointer flex items-center"
                        >
                          <span className={`w-3 h-3 rounded-full mr-2 ${getCategoryColorClass(category.color)}`}></span>
                          {category.name}
                        </label>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              <div>
                <h4 className="font-poppins font-medium text-neutral-dark mb-3">Price Range</h4>
                <Slider 
                  defaultValue={[0, 10]} 
                  max={10} 
                  step={0.5}
                  value={priceRange}
                  onValueChange={setPriceRange}
                />
                <div className="flex justify-between mt-2">
                  <span className="text-sm">${priceRange[0]}</span>
                  <span className="text-sm">${priceRange[1]}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-poppins font-medium text-neutral-dark mb-2">Product Type</h4>
                
                <div className="flex items-center">
                  <Checkbox 
                    id="featured"
                    checked={isFeatured}
                    onCheckedChange={(checked) => setIsFeatured(checked as boolean)}
                  />
                  <label htmlFor="featured" className="ml-2 text-sm font-medium cursor-pointer">
                    Featured
                  </label>
                </div>
                
                <div className="flex items-center">
                  <Checkbox 
                    id="organic"
                    checked={isOrganic}
                    onCheckedChange={(checked) => setIsOrganic(checked as boolean)}
                  />
                  <label htmlFor="organic" className="ml-2 text-sm font-medium cursor-pointer">
                    Organic
                  </label>
                </div>
                
                <div className="flex items-center">
                  <Checkbox 
                    id="bestseller"
                    checked={isBestSeller}
                    onCheckedChange={(checked) => setIsBestSeller(checked as boolean)}
                  />
                  <label htmlFor="bestseller" className="ml-2 text-sm font-medium cursor-pointer">
                    Best Seller
                  </label>
                </div>
                
                <div className="flex items-center">
                  <Checkbox 
                    id="newarrival"
                    checked={isNewArrival}
                    onCheckedChange={(checked) => setIsNewArrival(checked as boolean)}
                  />
                  <label htmlFor="newarrival" className="ml-2 text-sm font-medium cursor-pointer">
                    New Arrival
                  </label>
                </div>
                
                <div className="flex items-center">
                  <Checkbox 
                    id="seasonal"
                    checked={isSeasonal}
                    onCheckedChange={(checked) => setIsSeasonal(checked as boolean)}
                  />
                  <label htmlFor="seasonal" className="ml-2 text-sm font-medium cursor-pointer">
                    Seasonal
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Main Content - Products */}
        <div className="md:w-3/4">
          <div className="bg-white p-6 rounded-xl shadow-sm mb-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <h2 className="font-poppins font-bold text-2xl text-neutral-dark mb-2 md:mb-0">
                Shop Fruits
                {selectedCategory && categories && (
                  <> - {categories.find((c: Category) => c.slug === selectedCategory)?.name}</>
                )}
              </h2>
              <div className="text-sm text-neutral-dark/70">
                Showing {products?.length || 0} products
              </div>
            </div>
          </div>
          
          {productsLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(6).fill(0).map((_, index) => (
                <div key={index} className="animate-pulse bg-white rounded-xl overflow-hidden shadow-sm">
                  <div className="h-48 bg-gray-300"></div>
                  <div className="p-4">
                    <div className="h-6 bg-gray-300 rounded mb-2"></div>
                    <div className="h-4 bg-gray-300 rounded mb-3 w-3/4"></div>
                    <div className="h-6 bg-gray-300 rounded mb-4"></div>
                    <div className="h-10 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : products?.length === 0 ? (
            <div className="bg-white p-10 rounded-xl shadow-sm text-center">
              <i className="ri-information-line text-5xl text-primary mb-4"></i>
              <h3 className="font-poppins font-medium text-xl text-neutral-dark mb-2">No Products Found</h3>
              <p className="text-neutral-dark/70 mb-6">Try adjusting your filters or search criteria</p>
              <Button onClick={clearFilters} className="bg-primary hover:bg-primary/90 text-white">
                Clear Filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products?.map((product: Product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
