import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils";
import { Product, Category } from "@shared/schema";

export default function AdminProducts() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Partial<Product> | null>(null);
  const [isNewProduct, setIsNewProduct] = useState(false);
  
  // Fetch products
  const { data: products, isLoading } = useQuery({
    queryKey: ["/api/products"],
  });
  
  // Fetch categories
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });
  
  // Create product mutation
  const createProductMutation = useMutation({
    mutationFn: async (product: any) => {
      return apiRequest("POST", "/api/products", product);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setIsDialogOpen(false);
      toast({
        title: "Success",
        description: "Product created successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create product: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Update product mutation
  const updateProductMutation = useMutation({
    mutationFn: async ({ id, product }: { id: number; product: any }) => {
      return apiRequest("PUT", `/api/products/${id}`, product);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setIsDialogOpen(false);
      toast({
        title: "Success",
        description: "Product updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update product: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Delete product mutation
  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/products/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Success",
        description: "Product deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete product: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Handle edit product
  const handleEditProduct = (product: Product) => {
    setCurrentProduct(product);
    setIsNewProduct(false);
    setIsDialogOpen(true);
  };
  
  // Handle new product
  const handleNewProduct = () => {
    setCurrentProduct({
      name: "",
      slug: "",
      description: "",
      price: 0,
      imageUrl: "",
      unit: "kg",
      stock: 0,
      rating: 0,
      isFeatured: false,
      isOrganic: false,
      isBestSeller: false,
      isNewArrival: false,
      isSeasonal: false,
      categoryId: categories?.[0]?.id || 1,
    });
    setIsNewProduct(true);
    setIsDialogOpen(true);
  };
  
  // Handle delete product
  const handleDeleteProduct = (id: number) => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      deleteProductMutation.mutate(id);
    }
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    const formData = new FormData(e.currentTarget);
    const product = {
      name: formData.get("name") as string,
      slug: formData.get("slug") as string,
      description: formData.get("description") as string,
      price: parseFloat(formData.get("price") as string),
      imageUrl: formData.get("imageUrl") as string,
      unit: formData.get("unit") as string,
      stock: parseInt(formData.get("stock") as string),
      rating: parseFloat(formData.get("rating") as string),
      isFeatured: formData.get("isFeatured") === "on",
      isOrganic: formData.get("isOrganic") === "on",
      isBestSeller: formData.get("isBestSeller") === "on",
      isNewArrival: formData.get("isNewArrival") === "on",
      isSeasonal: formData.get("isSeasonal") === "on",
      categoryId: parseInt(formData.get("categoryId") as string),
    };
    
    if (isNewProduct) {
      createProductMutation.mutate(product);
    } else if (currentProduct?.id) {
      updateProductMutation.mutate({ id: currentProduct.id, product });
    }
  };
  
  // Generate slug from name
  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .replace(/[^\w\s-]/g, "")
      .replace(/[\s_-]+/g, "-")
      .replace(/^-+|-+$/g, "");
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="font-poppins font-bold text-3xl text-neutral-dark">Product Management</h1>
        <Button 
          className="bg-primary hover:bg-primary/90 text-white"
          onClick={handleNewProduct}
        >
          <i className="ri-add-line mr-2"></i>
          Add New Product
        </Button>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="p-8 flex justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : products?.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-neutral-dark/70 mb-4">No products found.</p>
            <Button 
              className="bg-primary hover:bg-primary/90 text-white"
              onClick={handleNewProduct}
            >
              Add Your First Product
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Image</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Flags</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products?.map((product: Product) => (
                  <TableRow key={product.id}>
                    <TableCell className="font-medium">{product.id}</TableCell>
                    <TableCell>
                      <div className="w-10 h-10 rounded-md overflow-hidden">
                        <img 
                          src={`${product.imageUrl}?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100`}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </TableCell>
                    <TableCell>{product.name}</TableCell>
                    <TableCell>{formatCurrency(product.price)}</TableCell>
                    <TableCell>{product.stock} {product.unit}</TableCell>
                    <TableCell>
                      {categories?.find((c: Category) => c.id === product.categoryId)?.name || "Unknown"}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {product.isFeatured && (
                          <span className="inline-block px-2 py-1 text-xs bg-primary/10 text-primary rounded-full">Featured</span>
                        )}
                        {product.isOrganic && (
                          <span className="inline-block px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full">Organic</span>
                        )}
                        {product.isBestSeller && (
                          <span className="inline-block px-2 py-1 text-xs bg-yellow-100 text-yellow-700 rounded-full">Best Seller</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                          onClick={() => handleEditProduct(product)}
                        >
                          <i className="ri-edit-line"></i>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:text-red-800 hover:bg-red-50"
                          onClick={() => handleDeleteProduct(product.id)}
                        >
                          <i className="ri-delete-bin-line"></i>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
      
      {/* Product Form Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {isNewProduct ? "Add New Product" : `Edit Product: ${currentProduct?.name}`}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="name" className="text-sm font-medium">
                  Product Name
                </label>
                <Input
                  id="name"
                  name="name"
                  defaultValue={currentProduct?.name}
                  required
                  onChange={(e) => {
                    if (isNewProduct || !(currentProduct?.slug)) {
                      // Auto-generate slug from name for new products
                      const slugInput = document.getElementById("slug") as HTMLInputElement;
                      if (slugInput) {
                        slugInput.value = generateSlug(e.target.value);
                      }
                    }
                  }}
                />
              </div>
              
              <div>
                <label htmlFor="slug" className="text-sm font-medium">
                  Slug
                </label>
                <Input
                  id="slug"
                  name="slug"
                  defaultValue={currentProduct?.slug}
                  required
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="description" className="text-sm font-medium">
                Description
              </label>
              <textarea
                id="description"
                name="description"
                className="w-full min-h-[100px] px-3 py-2 rounded-md border border-input"
                defaultValue={currentProduct?.description}
                required
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label htmlFor="price" className="text-sm font-medium">
                  Price
                </label>
                <Input
                  id="price"
                  name="price"
                  type="number"
                  step="0.01"
                  min="0"
                  defaultValue={currentProduct?.price}
                  required
                />
              </div>
              
              <div>
                <label htmlFor="unit" className="text-sm font-medium">
                  Unit
                </label>
                <Select name="unit" defaultValue={currentProduct?.unit || "kg"}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select unit" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="kg">Kilogram (kg)</SelectItem>
                    <SelectItem value="box">Box</SelectItem>
                    <SelectItem value="piece">Piece</SelectItem>
                    <SelectItem value="bunch">Bunch</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label htmlFor="stock" className="text-sm font-medium">
                  Stock
                </label>
                <Input
                  id="stock"
                  name="stock"
                  type="number"
                  min="0"
                  defaultValue={currentProduct?.stock}
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="imageUrl" className="text-sm font-medium">
                  Image URL
                </label>
                <Input
                  id="imageUrl"
                  name="imageUrl"
                  defaultValue={currentProduct?.imageUrl}
                  required
                />
              </div>
              
              <div>
                <label htmlFor="rating" className="text-sm font-medium">
                  Rating (0-5)
                </label>
                <Input
                  id="rating"
                  name="rating"
                  type="number"
                  min="0"
                  max="5"
                  step="0.1"
                  defaultValue={currentProduct?.rating ?? 4.5}
                  required
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="categoryId" className="text-sm font-medium">
                Category
              </label>
              <Select name="categoryId" defaultValue={String(currentProduct?.categoryId || categories?.[0]?.id)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map((category: Category) => (
                    <SelectItem key={category.id} value={String(category.id)}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="isFeatured"
                  name="isFeatured"
                  defaultChecked={currentProduct?.isFeatured}
                />
                <label htmlFor="isFeatured" className="text-sm font-medium">
                  Featured
                </label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="isOrganic"
                  name="isOrganic"
                  defaultChecked={currentProduct?.isOrganic}
                />
                <label htmlFor="isOrganic" className="text-sm font-medium">
                  Organic
                </label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="isBestSeller"
                  name="isBestSeller"
                  defaultChecked={currentProduct?.isBestSeller}
                />
                <label htmlFor="isBestSeller" className="text-sm font-medium">
                  Best Seller
                </label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="isNewArrival"
                  name="isNewArrival"
                  defaultChecked={currentProduct?.isNewArrival}
                />
                <label htmlFor="isNewArrival" className="text-sm font-medium">
                  New Arrival
                </label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="isSeasonal"
                  name="isSeasonal"
                  defaultChecked={currentProduct?.isSeasonal}
                />
                <label htmlFor="isSeasonal" className="text-sm font-medium">
                  Seasonal
                </label>
              </div>
            </div>
            
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-primary hover:bg-primary/90 text-white"
                disabled={createProductMutation.isPending || updateProductMutation.isPending}
              >
                {createProductMutation.isPending || updateProductMutation.isPending ? (
                  <>
                    <span className="animate-spin mr-2">
                      <i className="ri-loader-4-line"></i>
                    </span>
                    Saving...
                  </>
                ) : isNewProduct ? "Create Product" : "Update Product"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
