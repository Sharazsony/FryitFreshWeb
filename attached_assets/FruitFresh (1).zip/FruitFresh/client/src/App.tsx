import { Switch, Route } from "wouter";
import { useState, useEffect } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Shop from "@/pages/shop";
import ProductDetail from "@/pages/product-detail";
import Checkout from "@/pages/checkout";
import OrderConfirmation from "@/pages/order-confirmation";
import Orders from "@/pages/orders";
import AdminProducts from "@/pages/admin/products";
import AuthPage from "@/pages/auth-page";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import CartSidebar from "@/components/layout/cart-sidebar";
import { CartProvider } from "@/context/cart-context";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { nanoid } from "nanoid";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/shop" component={Shop} />
          <Route path="/product/:slug" component={ProductDetail} />
          <Route path="/auth" component={AuthPage} />
          <ProtectedRoute path="/checkout" component={Checkout} />
          <ProtectedRoute path="/orders" component={Orders} />
          <ProtectedRoute path="/order/:id" component={OrderConfirmation} />
          <ProtectedRoute path="/admin/products" component={AdminProducts} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  const [sessionId, setSessionId] = useState<string>("");
  
  useEffect(() => {
    // Get session ID from localStorage or create a new one
    let id = localStorage.getItem("fruit_market_session_id");
    if (!id) {
      id = nanoid();
      localStorage.setItem("fruit_market_session_id", id);
    }
    setSessionId(id);
  }, []);
  
  // Add session ID to all API requests
  useEffect(() => {
    if (sessionId) {
      const originalFetch = window.fetch;
      window.fetch = function(input, init) {
        init = init || {};
        init.headers = init.headers || {};
        init.headers = {
          ...init.headers,
          Authorization: `Bearer ${sessionId}`
        };
        return originalFetch(input, init);
      };
      
      return () => {
        window.fetch = originalFetch;
      };
    }
  }, [sessionId]);

  if (!sessionId) {
    return <div>Loading...</div>;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CartProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
            <CartSidebar />
          </TooltipProvider>
        </CartProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
