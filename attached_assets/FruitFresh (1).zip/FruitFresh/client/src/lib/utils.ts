import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function getStatusColor(status: string): string {
  switch (status.toLowerCase()) {
    case 'completed':
      return 'bg-green-500';
    case 'processing':
      return 'bg-blue-500';
    case 'pending':
      return 'bg-yellow-500';
    case 'cancelled':
      return 'bg-red-500';
    default:
      return 'bg-gray-500';
  }
}

export function getCategoryColorClass(color: string): string {
  switch (color) {
    case '#FF6B35':
      return 'bg-primary text-white';
    case '#4CAF50':
      return 'bg-secondary text-white';
    case '#9C27B0':
      return 'bg-accent text-white';
    case '#FF9F1C':
      return 'bg-orange-500 text-white';
    case '#E63946':
      return 'bg-red-500 text-white';
    case '#FCBF49':
      return 'bg-yellow-500 text-white';
    default:
      return 'bg-neutral-dark text-white';
  }
}

export function getDiscountedPrice(originalPrice: number, discountPercentage: number): number {
  if (discountPercentage <= 0) return originalPrice;
  const discount = (originalPrice * discountPercentage) / 100;
  return originalPrice - discount;
}

export function calculateTotal(items: any[]): number {
  return items.reduce((total, item) => {
    return total + (item.product.price * item.quantity);
  }, 0);
}
