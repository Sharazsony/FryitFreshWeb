import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCart } from "@/context/cart-context";
import { useAuth } from "@/hooks/use-auth";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

export default function Header() {
  const [, setLocation] = useLocation();
  const { cartItems, toggleCart } = useCart();
  const { user, logoutMutation } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  
  const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
  
  const handleToggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };
  
  const handleToggleSearch = () => {
    setIsSearchOpen(!isSearchOpen);
  };
  
  const handleSearchSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const searchQuery = formData.get("search") as string;
    if (searchQuery.trim()) {
      setLocation(`/shop?search=${encodeURIComponent(searchQuery)}`);
      setIsSearchOpen(false);
    }
  };
  
  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-primary text-3xl"><i className="ri-apple-fill"></i></span>
            <span className="font-poppins font-bold text-2xl text-neutral-dark">Fruit<span className="text-primary">Market</span></span>
          </Link>
          
          {/* Navigation - Desktop */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/">
              <a className="font-poppins font-medium text-neutral-dark hover:text-primary transition-colors">
                Home
              </a>
            </Link>
            <Link href="/shop">
              <a className="font-poppins font-medium text-neutral-dark hover:text-primary transition-colors">
                Shop
              </a>
            </Link>
            <Link href="/shop?category=seasonal">
              <a className="font-poppins font-medium text-neutral-dark hover:text-primary transition-colors">
                Categories
              </a>
            </Link>
            <Link href="/shop">
              <a className="font-poppins font-medium text-neutral-dark hover:text-primary transition-colors">
                About Us
              </a>
            </Link>
          </nav>
          
          {/* User Actions */}
          <div className="flex items-center space-x-4">
            <button 
              className="text-neutral-dark hover:text-primary transition-colors" 
              onClick={handleToggleSearch}
              aria-label="Search"
            >
              <i className="ri-search-line text-xl"></i>
            </button>
            
            {/* User dropdown menu or login button */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="text-neutral-dark hover:text-primary transition-colors flex items-center gap-1">
                    <i className="ri-user-line text-xl"></i>
                    <span className="hidden md:inline text-sm font-medium">{user.username}</span>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[200px]">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/orders">
                      <a className="w-full cursor-pointer">My Orders</a>
                    </Link>
                  </DropdownMenuItem>
                  {user.isAdmin && (
                    <DropdownMenuItem asChild>
                      <Link href="/admin/products">
                        <a className="w-full cursor-pointer">Admin</a>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={() => logoutMutation.mutate()}
                    className="cursor-pointer"
                  >
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/auth">
                <a className="text-neutral-dark hover:text-primary transition-colors">
                  <i className="ri-user-line text-xl"></i>
                  <span className="hidden md:inline ml-1 text-sm font-medium">Login</span>
                </a>
              </Link>
            )}
            
            {/* Cart button */}
            <button 
              className="relative text-neutral-dark hover:text-primary transition-colors" 
              onClick={toggleCart}
              aria-label="Open cart"
            >
              <i className="ri-shopping-basket-2-line text-xl"></i>
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {Math.ceil(totalItems)}
                </span>
              )}
            </button>
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-neutral-dark" 
              onClick={handleToggleMobileMenu}
              aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
            >
              <i className={`${isMobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-2xl`}></i>
            </button>
          </div>
        </div>
        
        {/* Search Bar (Hidden by default) */}
        {isSearchOpen && (
          <div className="pt-4">
            <form onSubmit={handleSearchSubmit}>
              <div className="flex items-center">
                <Input 
                  name="search"
                  type="text" 
                  placeholder="Search for fruits..." 
                  className="w-full rounded-lg" 
                  autoFocus
                />
                <Button type="submit" className="ml-2 bg-primary hover:bg-primary/90">
                  <i className="ri-search-line"></i>
                </Button>
              </div>
            </form>
          </div>
        )}
        
        {/* Mobile Menu (Hidden by default) */}
        {isMobileMenuOpen && (
          <div className="md:hidden">
            <nav className="py-4 space-y-3">
              <Link href="/">
                <a className="block font-poppins font-medium text-neutral-dark hover:text-primary transition-colors">
                  Home
                </a>
              </Link>
              <Link href="/shop">
                <a className="block font-poppins font-medium text-neutral-dark hover:text-primary transition-colors">
                  Shop
                </a>
              </Link>
              <Link href="/shop?category=seasonal">
                <a className="block font-poppins font-medium text-neutral-dark hover:text-primary transition-colors">
                  Categories
                </a>
              </Link>
              <Link href="/shop">
                <a className="block font-poppins font-medium text-neutral-dark hover:text-primary transition-colors">
                  About Us
                </a>
              </Link>
              
              {/* Auth Links for Mobile */}
              {user ? (
                <>
                  <div className="font-poppins font-medium text-primary">
                    Welcome, {user.username}
                  </div>
                  <Link href="/orders">
                    <a className="block font-poppins font-medium text-neutral-dark hover:text-primary transition-colors">
                      My Orders
                    </a>
                  </Link>
                  {user.isAdmin && (
                    <Link href="/admin/products">
                      <a className="block font-poppins font-medium text-neutral-dark hover:text-primary transition-colors">
                        Admin
                      </a>
                    </Link>
                  )}
                  <button 
                    className="block w-full text-left font-poppins font-medium text-neutral-dark hover:text-primary transition-colors"
                    onClick={() => logoutMutation.mutate()}
                  >
                    Logout
                  </button>
                </>
              ) : (
                <Link href="/auth">
                  <a className="block font-poppins font-medium text-neutral-dark hover:text-primary transition-colors">
                    Login / Register
                  </a>
                </Link>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
