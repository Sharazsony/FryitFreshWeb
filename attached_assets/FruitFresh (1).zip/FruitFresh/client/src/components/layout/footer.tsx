import { Link } from "wouter";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-neutral-dark text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <span className="text-primary text-3xl"><i className="ri-apple-fill"></i></span>
              <span className="font-poppins font-bold text-2xl">Fruit<span className="text-primary">Market</span></span>
            </div>
            <p className="text-white/70 mb-6 font-opensans">
              Providing fresh, high-quality fruits from local farms to your table. Freshness guaranteed.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white/70 hover:text-primary transition-colors" aria-label="Facebook">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="#" className="text-white/70 hover:text-primary transition-colors" aria-label="Instagram">
                <i className="ri-instagram-fill text-xl"></i>
              </a>
              <a href="#" className="text-white/70 hover:text-primary transition-colors" aria-label="Twitter">
                <i className="ri-twitter-fill text-xl"></i>
              </a>
              <a href="#" className="text-white/70 hover:text-primary transition-colors" aria-label="Pinterest">
                <i className="ri-pinterest-fill text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-poppins font-medium text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2 font-opensans">
              <li>
                <Link href="/">
                  <a className="text-white/70 hover:text-primary transition-colors">Home</a>
                </Link>
              </li>
              <li>
                <Link href="/shop">
                  <a className="text-white/70 hover:text-primary transition-colors">Shop</a>
                </Link>
              </li>
              <li>
                <Link href="/shop">
                  <a className="text-white/70 hover:text-primary transition-colors">About Us</a>
                </Link>
              </li>
              <li>
                <Link href="/shop">
                  <a className="text-white/70 hover:text-primary transition-colors">Contact</a>
                </Link>
              </li>
              <li>
                <Link href="/shop">
                  <a className="text-white/70 hover:text-primary transition-colors">FAQs</a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-poppins font-medium text-lg mb-4">Customer Service</h4>
            <ul className="space-y-2 font-opensans">
              <li>
                <Link href="/admin/products">
                  <a className="text-white/70 hover:text-primary transition-colors">My Account</a>
                </Link>
              </li>
              <li>
                <Link href="/shop">
                  <a className="text-white/70 hover:text-primary transition-colors">Track Order</a>
                </Link>
              </li>
              <li>
                <Link href="/shop">
                  <a className="text-white/70 hover:text-primary transition-colors">Shipping Policy</a>
                </Link>
              </li>
              <li>
                <Link href="/shop">
                  <a className="text-white/70 hover:text-primary transition-colors">Returns & Refunds</a>
                </Link>
              </li>
              <li>
                <Link href="/shop">
                  <a className="text-white/70 hover:text-primary transition-colors">Help Center</a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-poppins font-medium text-lg mb-4">Contact Us</h4>
            <ul className="space-y-3 font-opensans">
              <li className="flex items-start">
                <i className="ri-map-pin-line text-primary mt-1 mr-2"></i>
                <span className="text-white/70">123 Orchard Street, Fruitville, CA 94123</span>
              </li>
              <li className="flex items-center">
                <i className="ri-phone-line text-primary mr-2"></i>
                <span className="text-white/70">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center">
                <i className="ri-mail-line text-primary mr-2"></i>
                <span className="text-white/70">hello@fruitmarket.com</span>
              </li>
              <li className="flex items-center">
                <i className="ri-time-line text-primary mr-2"></i>
                <span className="text-white/70">Mon-Fri: 8AM-6PM, Sat: 9AM-5PM</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-6 border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-white/70 text-sm mb-4 md:mb-0 font-opensans">
              &copy; {currentYear} FruitMarket. All rights reserved.
            </p>
            <div className="flex items-center space-x-4">
              <Link href="/shop">
                <a className="text-white/70 hover:text-primary text-sm transition-colors font-opensans">
                  Privacy Policy
                </a>
              </Link>
              <Link href="/shop">
                <a className="text-white/70 hover:text-primary text-sm transition-colors font-opensans">
                  Terms of Service
                </a>
              </Link>
              <Link href="/shop">
                <a className="text-white/70 hover:text-primary text-sm transition-colors font-opensans">
                  Sitemap
                </a>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
