import { Button } from "@/components/ui/button";
import { CartItem } from "@/components/ui/cart-item";
import { useCart } from "@/context/cart-context";
import { formatCurrency, calculateTotal } from "@/lib/utils";
import { useLocation } from "wouter";

export default function CartSidebar() {
  const { cartItems, isCartOpen, toggleCart, isLoading } = useCart();
  const [, setLocation] = useLocation();
  
  const subtotal = calculateTotal(cartItems);
  const shipping = cartItems.length > 0 ? 3.99 : 0;
  const total = subtotal + shipping;
  
  const handleCheckout = () => {
    toggleCart();
    setLocation("/checkout");
  };
  
  return (
    <div className={`fixed inset-0 bg-black bg-opacity-50 z-50 transition-opacity ${isCartOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <div 
        className={`absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-lg transform transition-transform duration-300 ${isCartOpen ? 'translate-x-0' : 'translate-x-full'}`}
        aria-hidden={!isCartOpen}
      >
        <div className="flex flex-col h-full">
          {/* Cart Header */}
          <div className="p-4 border-b border-neutral-medium flex justify-between items-center">
            <h3 className="font-poppins font-medium text-xl text-neutral-dark">
              Your Basket ({cartItems.length})
            </h3>
            <button 
              className="text-neutral-dark hover:text-primary"
              onClick={toggleCart}
              aria-label="Close cart"
            >
              <i className="ri-close-line text-2xl"></i>
            </button>
          </div>
          
          {/* Cart Items */}
          <div className="flex-grow overflow-y-auto p-4 space-y-4">
            {isLoading ? (
              <div className="flex items-center justify-center h-32">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : cartItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-center">
                <i className="ri-shopping-basket-2-line text-5xl text-neutral-medium mb-4"></i>
                <h4 className="font-poppins font-medium text-lg text-neutral-dark mb-2">Your basket is empty</h4>
                <p className="text-neutral-dark/70 mb-6">Add some delicious fruits to your basket</p>
                <Button 
                  className="bg-primary hover:bg-primary/90 text-white" 
                  onClick={() => {
                    toggleCart();
                    setLocation("/shop");
                  }}
                >
                  Browse Products
                </Button>
              </div>
            ) : (
              cartItems.map(item => <CartItem key={item.id} item={item} />)
            )}
          </div>
          
          {/* Cart Summary */}
          {cartItems.length > 0 && (
            <div className="p-4 border-t border-neutral-medium">
              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="text-neutral-dark/70">Subtotal</span>
                  <span className="font-medium text-neutral-dark">{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-dark/70">Shipping</span>
                  <span className="font-medium text-neutral-dark">{formatCurrency(shipping)}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-neutral-medium">
                  <span className="font-poppins font-medium text-neutral-dark">Total</span>
                  <span className="font-poppins font-bold text-lg text-neutral-dark">{formatCurrency(total)}</span>
                </div>
              </div>
              
              <Button 
                className="w-full bg-primary text-white py-3 rounded-lg font-poppins font-medium hover:bg-primary/90 transition-colors mb-3"
                onClick={handleCheckout}
              >
                Proceed to Checkout
              </Button>
              <Button 
                variant="outline"
                className="w-full bg-transparent border border-neutral-medium text-neutral-dark py-2 rounded-lg font-poppins hover:bg-neutral-light transition-colors"
                onClick={toggleCart}
              >
                Continue Shopping
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
