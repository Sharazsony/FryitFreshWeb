import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/cart-context";
import { formatCurrency } from "@/lib/utils";
import { CartItemWithProduct } from "@shared/schema";

interface CartItemProps {
  item: CartItemWithProduct;
  compact?: boolean;
}

export function CartItem({ item, compact = false }: CartItemProps) {
  const { updateCartItem, removeCartItem } = useCart();
  const [isUpdating, setIsUpdating] = useState(false);
  
  const handleIncrease = async () => {
    setIsUpdating(true);
    await updateCartItem(item.id, item.quantity + 0.5);
    setIsUpdating(false);
  };
  
  const handleDecrease = async () => {
    if (item.quantity > 0.5) {
      setIsUpdating(true);
      await updateCartItem(item.id, item.quantity - 0.5);
      setIsUpdating(false);
    }
  };
  
  const handleRemove = async () => {
    await removeCartItem(item.id);
  };
  
  const totalPrice = item.product.price * item.quantity;
  
  if (compact) {
    return (
      <div className="flex justify-between items-center py-2">
        <div>
          <span className="font-medium text-neutral-dark">
            {item.quantity} × {item.product.name}
          </span>
        </div>
        <span className="font-medium text-neutral-dark">
          {formatCurrency(totalPrice)}
        </span>
      </div>
    );
  }
  
  return (
    <div className="flex items-center bg-neutral-light rounded-lg p-3">
      <div className="w-16 h-16 rounded-md overflow-hidden mr-3">
        <img 
          src={`${item.product.imageUrl}?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=200`}
          alt={item.product.name} 
          className="w-full h-full object-cover" 
        />
      </div>
      
      <div className="flex-grow">
        <h4 className="font-poppins font-medium text-neutral-dark">{item.product.name}</h4>
        <div className="flex justify-between items-center mt-1">
          <span className="text-sm text-neutral-dark/70">
            {formatCurrency(item.product.price)}/{item.product.unit} × {item.quantity}
          </span>
          <span className="font-poppins font-medium text-neutral-dark">
            {formatCurrency(totalPrice)}
          </span>
        </div>
        <div className="flex items-center space-x-3 mt-2">
          <div className="flex items-center space-x-2">
            <Button
              variant="outline" 
              size="icon"
              className="w-5 h-5 p-0 flex items-center justify-center bg-white rounded text-xs text-neutral-dark hover:text-primary border border-neutral-medium"
              onClick={handleDecrease}
              disabled={isUpdating || item.quantity <= 0.5}
              aria-label="Decrease quantity"
            >
              <i className="ri-subtract-line"></i>
            </Button>
            <span className="text-sm font-medium text-neutral-dark">
              {item.quantity}
            </span>
            <Button
              variant="outline"
              size="icon"
              className="w-5 h-5 p-0 flex items-center justify-center bg-white rounded text-xs text-neutral-dark hover:text-primary border border-neutral-medium"
              onClick={handleIncrease}
              disabled={isUpdating}
              aria-label="Increase quantity"
            >
              <i className="ri-add-line"></i>
            </Button>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-destructive hover:text-destructive/80 text-sm p-0 h-auto"
            onClick={handleRemove}
            disabled={isUpdating}
          >
            <i className="ri-delete-bin-line mr-1"></i> Remove
          </Button>
        </div>
      </div>
    </div>
  );
}
