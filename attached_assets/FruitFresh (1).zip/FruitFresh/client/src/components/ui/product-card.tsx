import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils";
import { useCart } from "@/context/cart-context";
import { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [isFavorite, setIsFavorite] = useState(false);

  const handleDecrease = () => {
    if (quantity > 1) {
      setQuantity(quantity - 0.5);
    }
  };

  const handleIncrease = () => {
    setQuantity(quantity + 0.5);
  };

  const handleAddToCart = () => {
    addToCart({
      productId: product.id,
      quantity,
    });
    
    toast({
      title: "Added to cart",
      description: `${product.name} (${quantity} ${product.unit}) has been added to your cart.`,
    });
  };

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsFavorite(!isFavorite);
  };

  const getBadgeClass = () => {
    if (product.isOrganic) return "bg-secondary text-white";
    if (product.isBestSeller) return "bg-yellow-500 text-white";
    if (product.isNewArrival) return "bg-purple-500 text-white";
    if (product.isSeasonal) return "bg-orange-500 text-white";
    return "bg-primary text-white";
  };

  const getBadgeText = () => {
    if (product.isOrganic) return "Organic";
    if (product.isBestSeller) return "Best Seller";
    if (product.isNewArrival) return "New Arrival";
    if (product.isSeasonal) return "Seasonal";
    return "Featured";
  };

  return (
    <Card className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="relative">
        <Link href={`/product/${product.slug}`}>
          <img 
            src={`${product.imageUrl}?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400`}
            alt={product.name}
            className="w-full h-48 object-cover cursor-pointer"
          />
        </Link>
        <div className="absolute top-3 left-3">
          <span className={`text-xs font-bold px-2 py-1 rounded-full ${getBadgeClass()}`}>
            {getBadgeText()}
          </span>
        </div>
        <button 
          className={`absolute top-3 right-3 bg-white rounded-full p-2 shadow-md hover:bg-primary hover:text-white transition-colors ${isFavorite ? 'text-primary' : ''}`}
          onClick={handleToggleFavorite}
          aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
        >
          <i className={isFavorite ? "ri-heart-fill" : "ri-heart-line"}></i>
        </button>
      </div>
      
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <Link href={`/product/${product.slug}`}>
            <h3 className="font-poppins font-medium text-lg text-neutral-dark cursor-pointer hover:text-primary">
              {product.name}
            </h3>
          </Link>
          <div className="flex items-center text-yellow-400 text-sm">
            <i className="ri-star-fill"></i>
            <span className="text-neutral-dark ml-1">{product.rating}</span>
          </div>
        </div>
        
        <p className="text-neutral-dark/70 text-sm mb-3 font-opensans">
          {product.description}
        </p>
        
        <div className="flex justify-between items-center mb-4">
          <div className="font-poppins">
            <span className="font-bold text-xl text-neutral-dark">{formatCurrency(product.price)}</span>
            <span className="text-sm text-neutral-dark/70">/{product.unit}</span>
          </div>
          
          <div className="flex items-center space-x-2 bg-neutral-light rounded-lg p-1">
            <button 
              className="w-6 h-6 flex items-center justify-center text-neutral-dark hover:text-primary"
              onClick={handleDecrease}
              aria-label="Decrease quantity"
            >
              <i className="ri-subtract-line"></i>
            </button>
            <span className="font-medium text-neutral-dark">{quantity}</span>
            <button 
              className="w-6 h-6 flex items-center justify-center text-neutral-dark hover:text-primary"
              onClick={handleIncrease}
              aria-label="Increase quantity"
            >
              <i className="ri-add-line"></i>
            </button>
          </div>
        </div>
        
        <Button 
          className="w-full bg-primary text-white py-2 rounded-lg font-poppins font-medium hover:bg-primary/90 transition-colors flex items-center justify-center space-x-2"
          onClick={handleAddToCart}
        >
          <i className="ri-shopping-basket-2-line"></i>
          <span>Add to Basket</span>
        </Button>
      </CardContent>
    </Card>
  );
}
