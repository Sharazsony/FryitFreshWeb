import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  price: doublePrecision("price").notNull(),
  imageUrl: text("image_url").notNull(),
  unit: text("unit").notNull().default("kg"),
  stock: integer("stock").notNull().default(0),
  rating: doublePrecision("rating").default(0),
  isFeatured: boolean("is_featured").default(false),
  isOrganic: boolean("is_organic").default(false),
  isBestSeller: boolean("is_best_seller").default(false),
  isNewArrival: boolean("is_new_arrival").default(false),
  isSeasonal: boolean("is_seasonal").default(false),
  categoryId: integer("category_id").notNull(),
});

export const cartItems = pgTable("cart_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  sessionId: text("session_id"),
  productId: integer("product_id").notNull(),
  quantity: doublePrecision("quantity").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  sessionId: text("session_id"),
  customerName: text("customer_name").notNull(),
  email: text("email").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  postalCode: text("postal_code").notNull(),
  phone: text("phone").notNull(),
  total: doublePrecision("total").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  productId: integer("product_id").notNull(),
  name: text("name").notNull(),
  price: doublePrecision("price").notNull(),
  quantity: doublePrecision("quantity").notNull(),
  unit: text("unit").notNull(),
});

// Insert schemas
// Custom email regex for strong validation
// This will reject emails with:
// - Leading special characters in the local part
// - Unacceptable TLDs
// - Various invalid patterns
export const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9._-]{0,61}[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z]{2,})+$/;

// List of valid TLDs that excludes uncommon or suspicious ones like .mail
const validTLDs = ["com", "org", "net", "edu", "gov", "io", "co", "app", "dev", "me", "tech", "info"];

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
}).extend({
  email: z.string()
    .min(5, "Email is required")
    .email("Invalid email format")
    .refine(
      (email) => emailRegex.test(email),
      "Invalid email format - must not start with special characters"
    )
    .refine(
      (email) => {
        const tld = email.split('.').pop() || '';
        return validTLDs.includes(tld.toLowerCase());
      },
      "Email domain not supported"
    ),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  slug: true,
  icon: true,
  color: true,
});

export const insertProductSchema = createInsertSchema(products).pick({
  name: true,
  slug: true,
  description: true,
  price: true,
  imageUrl: true,
  unit: true,
  stock: true,
  rating: true,
  isFeatured: true,
  isOrganic: true,
  isBestSeller: true,
  isNewArrival: true,
  isSeasonal: true,
  categoryId: true,
});

export const insertCartItemSchema = createInsertSchema(cartItems).pick({
  userId: true,
  sessionId: true,
  productId: true,
  quantity: true,
});

export const insertOrderSchema = createInsertSchema(orders).pick({
  userId: true,
  sessionId: true,
  customerName: true,
  email: true,
  address: true,
  city: true,
  postalCode: true,
  phone: true,
  total: true,
  status: true,
});

export const insertOrderItemSchema = createInsertSchema(orderItems).pick({
  orderId: true,
  productId: true,
  name: true,
  price: true,
  quantity: true,
  unit: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export type InsertCartItem = z.infer<typeof insertCartItemSchema>;
export type CartItem = typeof cartItems.$inferSelect;

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;
export type OrderItem = typeof orderItems.$inferSelect;

// Extended schemas for checkout
export const checkoutSchema = z.object({
  customerName: z.string().min(3, "Name is required"),
  email: z.string()
    .min(5, "Email is required")
    .email("Invalid email format")
    .refine(
      (email) => emailRegex.test(email),
      "Invalid email format - must not start with special characters"
    )
    .refine(
      (email) => {
        const tld = email.split('.').pop() || '';
        return validTLDs.includes(tld.toLowerCase());
      },
      "Email domain not supported"
    ),
  address: z.string().min(5, "Address is required"),
  city: z.string().min(2, "City is required"),
  postalCode: z.string().min(5, "Postal code is required"),
  phone: z.string().min(10, "Phone number is required"),
});

export type CheckoutData = z.infer<typeof checkoutSchema>;

// Product with category relation
export type ProductWithCategory = Product & {
  category: Category;
};

// Cart item with product relation
export type CartItemWithProduct = CartItem & {
  product: Product;
};

// Order with items relation
export type OrderWithItems = Order & {
  items: OrderItem[];
};
